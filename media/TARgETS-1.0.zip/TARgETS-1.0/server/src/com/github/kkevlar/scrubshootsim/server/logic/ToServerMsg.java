package com.github.kkevlar.scrubshootsim.server.logic;

public class ToServerMsg {
	public byte[] data;
	public int length;
	public int code;
	public MessageContext context;
}
