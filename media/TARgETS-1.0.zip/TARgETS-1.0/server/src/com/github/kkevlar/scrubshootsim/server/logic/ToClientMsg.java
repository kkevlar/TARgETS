package com.github.kkevlar.scrubshootsim.server.logic;

public class ToClientMsg {
	public byte[] data;
	public int code;
	public int length;
}
