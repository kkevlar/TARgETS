/usr/lib/jvm/java-8-openjdk-amd64/bin/java -Dfile.encoding=UTF-8 -classpath /home/kevlar/targets/server/bin com.github.kkevlar.scrubshootsim.server.logic.ShootServerMain

